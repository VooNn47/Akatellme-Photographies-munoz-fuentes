package com.akatellme.service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akatellme.service.model.TipoSesion;
import com.akatellme.service.repository.TipoSesionRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping("/sesion")
public class TiposesionController 
{
    @Autowired
    private TipoSesionRepository tipoSesionRepository;
    @PostMapping("/guardar")
    public TipoSesion guardarSesion(@RequestBody TipoSesion tipoSesion)
    {
        return tipoSesionRepository.save(tipoSesion);
    }
    @GetMapping("/listar")
    public List<TipoSesion> listarsesiones() {
        return tipoSesionRepository.findAll();
    }
    


}
