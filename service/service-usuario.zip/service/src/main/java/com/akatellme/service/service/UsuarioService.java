package com.akatellme.service.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akatellme.service.model.Usuario;
import com.akatellme.service.repository.UsuarioRepository;

import jakarta.transaction.Transactional;

@Service
public class UsuarioService 
{
    @Autowired
    private UsuarioRepository usuarioRepository;
    public List<Usuario> listartodo()
    {
        return usuarioRepository.findAll();
    }
    public Optional<Usuario> BuscarporID(Long id)
    {
        return usuarioRepository.findById(id);
    }
    @Transactional
    public Usuario guardar( Usuario usuario)
    {
         return usuarioRepository.save(usuario);
    }

    public void eliminar (Long id){
        usuarioRepository.deleteById(id);
    

}
}
