package com.akatellme.service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akatellme.service.model.TipoDeusuario;
import com.akatellme.service.repository.TipoUsuarioRepository;

@RestController
@RequestMapping("/usuario/tipo")
public class TipoUsuarioController 
{
    @Autowired
    private TipoUsuarioRepository repository;
    @GetMapping
    public List<TipoDeusuario>listar(){
        return repository.findAll();
    }
    @PostMapping
    public TipoDeusuario crear(@RequestBody TipoDeusuario tipoDeusuario)
    {
        return repository.save(tipoDeusuario);
    }

}
